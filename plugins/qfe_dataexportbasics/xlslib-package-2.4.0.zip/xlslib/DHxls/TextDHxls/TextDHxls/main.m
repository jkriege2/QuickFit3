//
//  main.m
//  TextDHxls
//
//  Created by David Hoerl on 3/5/13.
//  Copyright (c) 2013 David Hoerl. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
	return NSApplicationMain(argc, (const char **)argv);
}
