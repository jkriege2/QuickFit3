//
//  AppDelegate.h
//  TextDHxls
//
//  Created by David Hoerl on 3/5/13.
//  Copyright (c) 2013 David Hoerl. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
