//
//  main.m
//  TestDHxlsIOS
//
//  Created by David Hoerl on 3/8/13.
//  Copyright (c) 2013 David Hoerl. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
	}
}
