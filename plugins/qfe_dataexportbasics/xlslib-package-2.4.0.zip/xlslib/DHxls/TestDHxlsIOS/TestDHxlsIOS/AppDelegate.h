//
//  AppDelegate.h
//  TestDHxlsIOS
//
//  Created by David Hoerl on 3/8/13.
//  Copyright (c) 2013 David Hoerl. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
