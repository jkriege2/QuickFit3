/* $Id: dummy.c,v 1.2.2.2 2010-06-08 18:50:43 bfriesen Exp $ */

/*
 * Dummy function, just to be ensure that the library always will be created.
 */

void
libport_dummy_function()
{
        return;
}

/*
 * Local Variables:
 * mode: c
 * c-basic-offset: 8
 * fill-column: 78
 * End:
 */
